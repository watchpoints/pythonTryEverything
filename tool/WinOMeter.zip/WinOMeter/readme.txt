WinOMeter v1.50
Freeware (you can use it for free)
June, 7th 2010
Copyright (c) 2004-2010 by Tomas Jelinek

Features
This small utility measures your computer activity. 
It counts the keyboard / mouse presses and computes trajectory that you have arrived by your mouse. 
You can easily set it up to be automatically loaded on startup if you would like to have captured all your activity. 
Every day is saved into history, so you can make statistics of your activity (averaging..).
You can also export your whole history to a CSV file (comma separated values) which may be used later in e.g MS Excel.
You can do it from the right click menu of from the command line (e.g. winometer.exe /exporthistory history.csv)

Installation
Unzip winometer.zip into any suitable folder in your hard disk.
Run winometer.exe. By left mouse click on the program icon in the tray you can display its window.
If you want, bring up the context menu (right mouse click on WinOMeter window) a select menu item "Load on startup". Then, WinOMeter will automatically run from this location each time you log in.

Download
winometer.zip [~100 KB] 

Contact
Should you have any questions/suggestions, do not hesitate to contact me.
e-mail: support@tjelinek.com

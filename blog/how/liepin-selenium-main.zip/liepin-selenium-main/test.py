
import showdata

if __name__ == '__main__':
    showdata.draw()